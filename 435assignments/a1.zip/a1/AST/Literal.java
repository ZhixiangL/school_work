package AST;

public abstract class Literal extends Expression {}
