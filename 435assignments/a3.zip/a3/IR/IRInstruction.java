package IR;

public abstract class IRInstruction {

}